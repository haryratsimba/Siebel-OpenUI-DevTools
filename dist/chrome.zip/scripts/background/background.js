"use strict";

// https://developer.chrome.com/extensions/devtools
// https://github.com/Maluen/Backbone-Debugger/blob/master/js/background.js

/*
  NB : The background is shared between the browser tabs, therefore it
 identifies the various panel communication ports by using the id of the
 tab they belong to.
*/
var connectionsMapping = {};

// Listen for a connection creation from devtools and save this connection
chrome.runtime.onConnect.addListener(function (port) {

    var onDevToolsConnectionListener = function onDevToolsConnectionListener(message, sender, sendResponse) {
        // The tab ID is provided in Devtools message because the background page has not tab ID access
        if (message.name === "initConnection") {
            connectionsMapping[message.tabId] = port;
            return;
        }
    };

    // Listen to connection message sent from the DevTools page, then save the connection
    port.onMessage.addListener(onDevToolsConnectionListener);

    port.onDisconnect.addListener(function (port) {
        port.onMessage.removeListener(onDevToolsConnectionListener);

        var tabs = Object.keys(connections);
        for (var i = 0; i < tabs.length; i++) {
            if (connections[tabs[i]] == port) {
                delete connections[tabs[i]];
                break;
            }
        }
    });
});

// Listen for content-script messages
chrome.runtime.onMessage.addListener(function (siebelApp, sender, sendResponse) {
    if (sender.tab) {
        var tabId = sender.tab.id;
        if (tabId in connectionsMapping) {
            connections[tabId].postMessage(request);
        } else {
            console.log("Tab not found in connection list.");
        }
    } else {
        console.log('sender.tab not defined');
    }

    return true;
});
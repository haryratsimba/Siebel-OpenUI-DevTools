"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
var a = 10;

exports.default = a;
'use strict';

// Create the custom devtools panel
chrome.devtools.panel.create('Siebel OpenUI', null, 'panel/panel.html');
"use strict";

var siebApp = SiebelApp && SiebelApp.S_App;

if (siebApp) {
    chrome.runtime.sendMessage(siebApp);
}